#include <stdio.h>
int pi = 3.14``
struct S {
    int a;
    int b;
} s, *sp;
int g = 12;
int f(int a, int b) {
    return a + b;
}

int main() {
    int local;
    s.a = 1;
    s.b = 2;
    sp = &s;
    s.a = g + s.b;
    if (s.a > 0) {
        local = 34;
    } else {
        local = 35;
    }
    printf("%d\n", g + local);
}