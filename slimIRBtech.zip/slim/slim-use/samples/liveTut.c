#include <stdio.h>

int main() {
    int a = 4;
    int b = 2;
    int c = 3;
    int m = c * 2;

    while (a <= m) {
        a = a + 1;
    }

    if (a < 12) {
        int t1 = a + b;
        a = t1 + c;
        printf("Hi\n");
    }

    printf("Hello\n");
    return 0;
}

