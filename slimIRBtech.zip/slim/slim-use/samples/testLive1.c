int test(int a, int b) {
  int x = a + b;
  int y = x + 1;
  int z = y + 2;
  return z;
}

