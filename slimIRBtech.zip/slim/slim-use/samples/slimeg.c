int main()
{
	int x,y;
	y=5;
	x=y;
	return x;
	
}
