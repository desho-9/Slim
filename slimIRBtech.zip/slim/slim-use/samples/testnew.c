void first() {

	
}

void second() {
	first();

}

int main() {
	first();
	second();
	first();
	second();
	return 0;

}
