#include "llvm/IR/Function.h"
#include "llvm/IR/BasicBlock.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/InstrTypes.h"
#include "llvm/Passes/PassBuilder.h"
#include "llvm/Passes/PassPlugin.h"
#include "llvm/IR/PassManager.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/IR/CFG.h"

#include <unordered_map>
#include <set>
#include <vector>
#include <string>

using namespace llvm;

using VarSet = std::set<std::string>;

struct LiveVariablesPass : public PassInfoMixin<LiveVariablesPass> {
    std::unordered_map<BasicBlock*, VarSet> GEN, KILL, IN, OUT;
    std::unordered_map<BasicBlock*, int> BlockNumber;
    std::vector<BasicBlock*> BlockList;
    std::unordered_map<BasicBlock*, std::vector<VarSet>> INHistory, OUTHistory;

    PreservedAnalyses run(Function &F, FunctionAnalysisManager &FAM) {
        numberBlocks(F);
        computeGenKill(F);
        dataflowAnalysis(F);
        printGenKillTable();
        printGlobalFlowInfo();
        return PreservedAnalyses::all();
    }

    void numberBlocks(Function &F) {
        int counter = 1;
        for (BasicBlock &BB : F) {
            BlockNumber[&BB] = counter++;
            BlockList.push_back(&BB);
        }
    }

    void computeGenKill(Function &F) {
        for (BasicBlock *BB : BlockList) {
            VarSet gen, kill;
            std::set<std::string> definedNames;

            // First pass: Identify initial definitions in the entry block
            if (BlockNumber[BB] == 1) { // Assuming the first block is the entry
                for (auto &I : *BB) { // Forward iteration for initial definitions
                    if (auto *SI = dyn_cast<StoreInst>(&I)) {
                        if (auto *Ptr = dyn_cast<PointerType>(SI->getPointerOperandType())) {
                            if (auto *Alloc = dyn_cast<AllocaInst>(SI->getPointerOperand())) {
                                if (Alloc->hasName()) {
                                    definedNames.insert(Alloc->getName().str());
                                } else if (SI->getPointerOperand()->hasName()) {
                                    definedNames.insert(SI->getPointerOperand()->getName().str());
                                }
                            } else if (SI->getPointerOperand()->hasName()) {
                                definedNames.insert(SI->getPointerOperand()->getName().str());
                            }
                        }
                    } else if (I.hasName() && !I.getType()->isVoidTy()) {
                        definedNames.insert(I.getName().str());
                    }
                }
            }

            // Second pass: Reverse traversal for Gen and Kill
            for (auto instIt = BB->rbegin(); instIt != BB->rend(); ++instIt) {
                Instruction &I = *instIt;

                // Check for variable uses
                for (Use &U : I.operands()) {
                    if (auto *V = dyn_cast<Value>(U.get())) {
                        if ((isa<Instruction>(V) || isa<Argument>(V)) && V->hasName()) {
                            std::string varName = V->getName().str();
                            if (definedNames.find(varName) == definedNames.end()) {
                                gen.insert(varName);
                            }
                        }
                    }
                }

                // Check for variable definitions
                if (I.hasName()) {
                    std::string defName = I.getName().str();
                    kill.insert(defName);
                    definedNames.insert(defName);
                }
            }
            GEN[BB] = gen;
            KILL[BB] = kill;
        }
    }
    void dataflowAnalysis(Function &F) {
        for (BasicBlock *BB : BlockList) {
            IN[BB] = {};
            OUT[BB] = {};
        }

        bool changed = true;
        while (changed) {
            changed = false;

            std::unordered_map<BasicBlock*, VarSet> newIN, newOUT;

            for (BasicBlock *BB : BlockList) {
                VarSet out;
                for (BasicBlock *Succ : successors(BB)) {
                    out.insert(IN[Succ].begin(), IN[Succ].end());
                }
                newOUT[BB] = out;

                VarSet in = GEN[BB];
                for (const auto &var : out) {
                    if (KILL[BB].find(var) == KILL[BB].end()) {
                        in.insert(var);
                    }
                }
                newIN[BB] = in;

                if (in != IN[BB] || out != OUT[BB]) {
                    changed = true;
                }
            }

            for (BasicBlock *BB : BlockList) {
                IN[BB] = newIN[BB];
                OUT[BB] = newOUT[BB];
                INHistory[BB].push_back(IN[BB]);
                OUTHistory[BB].push_back(OUT[BB]);
            }
        }
    }

    void printSet(const VarSet &s) {
        errs() << "{";
        for (auto it = s.begin(); it != s.end(); ++it) {
            errs() << *it;
            if (std::next(it) != s.end())
                errs() << ", ";
        }
        errs() << "}";
    }

    void printGenKillTable() {
        errs() << "Local Data Flow Information\n";
        errs() << "Block\tGen\t\tKill\n";
        for (BasicBlock *BB : BlockList) {
            errs() << BlockNumber[BB] << "\t";
            printSet(GEN[BB]);
            errs() << "\t";
            printSet(KILL[BB]);
            errs() << "\n";
        }
        errs() << "\n";
    }

    void printGlobalFlowInfo() {
    int numIters = INHistory[BlockList.front()].size();
    errs() << "Global Data Flow Information\n";

    // Print header with iteration number labels
    errs() << "Block";
    for (int i = 0; i < numIters; ++i) {
        errs() << "\tIter #" << (i + 1);
    }
    errs() << "\n";

    // Print the data for each block for each iteration
    for (BasicBlock *BB : BlockList) {
        errs() << "Block " << BlockNumber[BB];
        for (int i = 0; i < numIters; ++i) {
            // Print Out and In sets for each iteration, each on a new line
            errs() << "\n";
            errs() << "Iteration #" << (i + 1) << ":\n";
            errs() << "   Out: ";
            printSet(OUTHistory[BB][i]);
            errs() << "\n";
            errs() << "   In: ";
            printSet(INHistory[BB][i]);
            errs() << "\n";
        }
    }
    errs() << "\n";
}
};

extern "C" LLVM_ATTRIBUTE_WEAK ::llvm::PassPluginLibraryInfo llvmGetPassPluginInfo() {
    return {
        LLVM_PLUGIN_API_VERSION, "LiveVariablesPass", LLVM_VERSION_STRING,
        [](PassBuilder &PB) {
            PB.registerPipelineParsingCallback(
                [](StringRef Name, FunctionPassManager &FPM,
                   ArrayRef<PassBuilder::PipelineElement>) {
                    if (Name == "live-vars") {
                        FPM.addPass(LiveVariablesPass());
                        return true;
                    }
                    return false;
                });
        }};
}

