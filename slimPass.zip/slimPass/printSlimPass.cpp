#include "llvm/IR/PassManager.h"
#include "llvm/Passes/PassBuilder.h"
#include "llvm/Passes/PassPlugin.h"
#include "llvm/IR/Module.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/Transforms/IPO/PassManagerBuilder.h"
#include "llvm/Transforms/Utils/Cloning.h"


#include <slim/IR.h>  // Make sure this path is correct

using namespace llvm;

namespace {

struct PrintSlimPass : PassInfoMixin<PrintSlimPass> {
    PreservedAnalyses run(Module &M, ModuleAnalysisManager &) {
        errs() << "Running PrintSlimPass on module: " << M.getName() << "\n";
    
        // Verify the module
        if (llvm::verifyModule(M, &errs())) {
            errs() << "Error: Module verification failed.\n";
            return PreservedAnalyses::all();
        }
    
        for (Function &F : M) {
            if (F.isIntrinsic() || F.isDeclaration()) {
                continue;
            }
    
            errs() << "Function: " << F.getName() << "\n";
    
            for (BasicBlock &BB : F) {
                errs() << "BasicBlock: " << BB.getName() << "\n";
    
                for (Instruction &I : BB) {
                    errs() << "Instruction: ";
                    I.print(errs());
                    errs() << "\n";
    
                    // Convert to SLIM instruction
                    BaseInstruction *slimInstruction = slim::convertLLVMToSLIMInstruction(I);
                    if (slimInstruction) {
                        llvm::outs() << "SLIM Instruction: ";
                        slimInstruction->printInstruction();
                        llvm::outs() << "\n";
                    } else {
                        llvm::errs() << "Failed to convert LLVM instruction to SLIM instruction.\n";
                    }
                }
            }
        }
    
        return PreservedAnalyses::all();
    }
};

} // end anonymous namespace

// Register the pass with LLVM's Pass Plugin system
extern "C" ::llvm::PassPluginLibraryInfo llvmGetPassPluginInfo() {
    return {
        LLVM_PLUGIN_API_VERSION, "PrintSlimPass", LLVM_VERSION_STRING,
        [](PassBuilder &PB) {
            PB.registerPipelineParsingCallback(
                [](StringRef Name, ModulePassManager &MPM,
                   ArrayRef<PassBuilder::PipelineElement>) {
                    if (Name == "print-slim") {
                        MPM.addPass(PrintSlimPass());
                        return true;
                    }
                    return false;
                });
        }
    };
}