#include "llvm/IR/PassManager.h"
#include "llvm/IR/Function.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/Module.h"
#include "llvm/Passes/PassPlugin.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/Passes/PassBuilder.h" // Required for PassBuilder
#include "llvm/Passes/PassPlugin.h"  // Required for pass registration
#include "llvm/IR/PassManager.h" 
using namespace llvm;

namespace {

struct PrintCFGPass : PassInfoMixin<PrintCFGPass> {
    PreservedAnalyses run(Function &F, FunctionAnalysisManager &) {
        errs() << "Function: " << F.getName() << "\n";
        for (auto &BB : F) {
            errs() << "BasicBlock: " << BB.getName() << "\n";
            for (auto &I : BB) {
                errs() << "  Instruction: " << I << "\n";
            }
        }
        return PreservedAnalyses::all();
    }
};
}

// Register the pass with the new PassManager
extern "C" LLVM_ATTRIBUTE_WEAK ::llvm::PassPluginLibraryInfo llvmGetPassPluginInfo() {
    return {
        LLVM_PLUGIN_API_VERSION, "PrintCFGPass", LLVM_VERSION_STRING,
        [](PassBuilder &PB) {
            PB.registerPipelineParsingCallback(
                [](StringRef Name, FunctionPassManager &FPM,
                   ArrayRef<PassBuilder::PipelineElement>) {
                    if (Name == "print-cfg") {
                        FPM.addPass(PrintCFGPass());
                        return true;
                    }
                    return false;
                });
        }};
}

