#include <stdio.h>

int p = 3.14, radius = 20, y, *x = &y;


void main() {
    printf("Area of Circle = %d", area());
}

int area() {
    return p * radius * radius;
}