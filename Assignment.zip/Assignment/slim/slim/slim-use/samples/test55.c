#include <stdio.h>

int printMessage() {
    int* r=malloc(sizeof(int));
    return r;
}

int main() {
    // Declare a function pointer that takes no arguments and returns void
    int (*ptr)();

    // Assign the address of the printMessage function to the function pointer
    ptr = printMessage();

    // Call the function using the function pointer
    //ptr();

    return *ptr;
}
