#include <stdio.h>

int main() {
    int x = 5;
    int y = 10;
    int z = x + y;
    int a = z * 2;

    if (a > 20) {
        printf("a is greater than 20\n");

        if (x > 2) {
            printf("x is greater than 2\n");
        } else {
            printf("x is not greater than 2\n");
        }
    } else {
        printf("a is not greater than 20\n");

        if (y < 5) {
            printf("y is less than 5\n");
        } else {
            printf("y is not less than 5\n");
        }
    }

    return 0;
}
