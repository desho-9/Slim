#include <stdio.h>
#include <stdlib.h>
int* ptr;
// Function to allocate memory and return the value pointed to by the allocated memory
int* allocateAndReturn() {
    ptr = malloc(sizeof(int));
    
    return ptr;
}

int main() {
    int *result2, *result3,result4;
    result2=allocateAndReturn();
    result3=allocateAndReturn();
    //result4=allocateAndReturn();
    
    if(result2!=result3)
    {
        printf("fail");
    }
    return *result2;
}
