*********MAKE SURE U HAVE LLVM-14, CMAKE-3.27.4 and SLIM INSTALLED!!***********

Step-1) Open the slimPass folder

Step-2) Open the terminal from this location.

Step-3) Build the pass by executing the run.sh file using the following command...
         ---> ./run.sh

Step-4) Build folder will be created.

Step-5) You should find a shared object file called PrintSlimPass.so in the build folder.

Step-6) The flow of execution is as follows:
         ----> Input c file 
         ----> get the corresponding llvm bitcode file(.ll file) 
         ----> Run our pass on this .ll file using the opt command given below 

Step-7) To generate the .ll file go to the location where u installed slim. Click on the slim folder, click on slim-use folder, you'll find a file called slim.sh.
        Open the terminal from this location and run the following command.
         ---> ./slim.sh <path to your c file>
         ---> example: ./slim.sh /home/example.c 

Step-8) Now the corressponding .ll file for your c file will be generated. You will find the .ll file in the samples folder inside the slim-use folder.
        The name of the .ll file will be same as your c file. (example.c ---> example.ll)
        Copy the path of this newly generated .ll file and go back to the location where you built your pass.

Step-9) To run our pass use the following command...
	   ---> opt -load-pass-plugin <path to the .so file> -passes=print-slim <path to the llvm bitcode file>
	   ---> example(from inside build folder): opt -load-pass-plugin ./PrintSlimPass.so -passes=print-slim test1.ll   

Step-10) Congratulations!! You have done it! The output will be printed in the terminal.

******DO NOT EXPECT TO GET IT RIGHT ON YOUR FIRST TRY! YOU WILL FACE ERRORS BUT DO NOT GIVE UP, GIVE IT ANOTHER SHOT AND ANOTHER AND ANOTHER UNTIL U SUCCEED!********
******IT TOOK ME ALMOST 10-20 TRIES AND LOT'S OF SLEEPLESS NIGHTS TO GET IT RIGHT. LUCKY FOR U, WE'RE HERE TO HELP U GET IT RIGHT IN FEWER TRIES!!*******
